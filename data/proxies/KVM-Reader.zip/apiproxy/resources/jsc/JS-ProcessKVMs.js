try {
    var kvmListResponse = JSON.parse(context.getVariable("kvm.list.response.content"));
    var orgName = context.getVariable("organization.name");
    var envName = context.getVariable("environment.name");
    var authHeader = context.getVariable("auth.header");
    var managementUrl = "http://127.0.0.1:8080/v1/organizations/" + orgName;

    // Get scope from query parameter (organization, environment)
    var scope = context.getVariable("request.queryparam.scope") || "environment";

    var kvmNames = kvmListResponse || [];
    var allKVMData = [];

    // Function to get KVM details (structure with entry names)
    function getKVMDetails(kvmName, scope) {
        var url;
        if (scope === "environment") {
            url = managementUrl + "/environments/" + envName + "/keyvaluemaps/" + kvmName;
        } else if (scope === "organization") {
            url = managementUrl + "/keyvaluemaps/" + kvmName;
        } else {
            url = managementUrl + "/keyvaluemaps/" + kvmName;
        }
        
        var req = new Request(url, "GET", {
            "Authorization": authHeader
        });
        
        var exchange = httpClient.send(req);
        exchange.waitForComplete();
        
        if (exchange.isSuccess()) {
            return exchange.getResponse().content.asJSON;
        } else {
            return null;
        }
    }

    // Function to get individual entry value
    function getKVMEntryValue(kvmName, entryName, scope) {
        var url;
        if (scope === "environment") {
            url = managementUrl + "/environments/" + envName + "/keyvaluemaps/" + kvmName + "/entries/" + entryName;
        } else if (scope === "organization") {
            url = managementUrl + "/keyvaluemaps/" + kvmName + "/entries/" + entryName;
        } else {
            url = managementUrl + "/keyvaluemaps/" + kvmName + "/entries/" + entryName;
        }
        
        var req = new Request(url, "GET", {
            "Authorization": authHeader
        });
        
        var exchange = httpClient.send(req);
        exchange.waitForComplete();
        
        if (exchange.isSuccess()) {
            var entryData = exchange.getResponse().content.asJSON;
            return entryData.value;
        } else {
            return null;
        }
    }

    // Process each KVM
    for (var i = 0; i < kvmNames.length; i++) {
        var kvmName = kvmNames[i];
        var kvmDetails = getKVMDetails(kvmName, scope);
        
        if (kvmDetails && kvmDetails.entry) {
            var entries = {};
            
            // Get the actual value for each entry
            for (var j = 0; j < kvmDetails.entry.length; j++) {
                var entryName = kvmDetails.entry[j].name;
                var entryValue = getKVMEntryValue(kvmName, entryName, scope);
                
                entries[entryName] = {
                    value: entryValue,
                    encrypted: kvmDetails.encrypted || false
                };
            }
            
            allKVMData.push({
                name: kvmName,
                encrypted: kvmDetails.encrypted || false,
                scope: scope,
                entries: entries,
                entryCount: kvmDetails.entry.length
            });
        } else {
            allKVMData.push({
                name: kvmName,
                error: "Failed to retrieve KVM details",
                scope: scope
            });
        }
    }

    // Create the response object
    var responseObj = {
        organization: orgName,
        environment: envName,
        scope: scope,
        kvmCount: allKVMData.length,
        kvms: allKVMData
    };

    // Set response in flow variable
    var responseString = JSON.stringify(responseObj, null, 2);
    context.setVariable("kvm.response.body", responseString);
    context.setVariable("response.header.Content-Type", "application/json");

} catch (e) {
    // If there's an error, set an error response
    var errorResponse = JSON.stringify({
        error: true,
        message: "Error in processKVMs: " + e.toString(),
        stack: e.stack
    }, null, 2);
    
    context.setVariable("kvm.response.body", errorResponse);
    context.setVariable("response.header.Content-Type", "application/json");
}