try {
    var kvmName = context.getVariable("kvm.name");
    var scope = context.getVariable("kvm.scope");
    var newEntriesJson = context.getVariable("kvm.entries");
    var authHeader = context.getVariable("auth.header");
    var orgName = context.getVariable("organization.name");
    var envName = context.getVariable("environment.name");
    
    var newEntries = JSON.parse(newEntriesJson);
    
    // Build URL for getting and updating the KVM
    var baseUrl;
    if (scope === "environment") {
        baseUrl = "http://127.0.0.1:8080/v1/organizations/" + orgName + "/environments/" + envName + "/keyvaluemaps/" + kvmName;
    } else if (scope === "organization") {
        baseUrl = "http://127.0.0.1:8080/v1/organizations/" + orgName + "/keyvaluemaps/" + kvmName;
    } else {
        throw new Error("Invalid scope");
    }
    
    // Step 1: GET the current KVM to retrieve existing entries
    var getReq = new Request(baseUrl, "GET", {
        "Authorization": authHeader,
        "Content-Type": "application/json"
    });
    
    var getExchange = httpClient.send(getReq);
    getExchange.waitForComplete();
    
    var getStatus = getExchange.getResponse().status;
    var getStatusCode = typeof getStatus === 'object' ? getStatus.code : getStatus;
    var getStatusMessage = typeof getStatus === 'object' ? getStatus.message : "";
    
    var errorContent = "";
    try {
        errorContent = getExchange.getResponse().content.asString;
    } catch (e) {
        errorContent = "Could not read error content";
    }
    
    if (!getExchange.isSuccess() || (getStatusCode != "200" && getStatusCode != 200)) {
        throw new Error("Failed to retrieve existing KVM '" + kvmName + "'. Status: " + getStatusCode + " (" + getStatusMessage + "), Response: " + errorContent + ", URL: " + baseUrl);
    }
    
    var currentKVM = getExchange.getResponse().content.asJSON;
    var existingEntries = currentKVM.entry || [];
    var isEncrypted = currentKVM.encrypted || false;
    
    // Safety check for encrypted KVMs
    if (isEncrypted) {
        // For encrypted KVMs, we can only safely add NEW entries or replace ALL entries
        // Check if user is providing all existing entry names
        var existingKeys = {};
        for (var i = 0; i < existingEntries.length; i++) {
            existingKeys[existingEntries[i].name] = true;
        }
        
        var providedKeys = {};
        for (var key in newEntries) {
            if (newEntries.hasOwnProperty(key)) {
                providedKeys[key] = true;
            }
        }
        
        // Check if any existing keys are missing from the update
        var missingKeys = [];
        for (var existingKey in existingKeys) {
            if (!providedKeys[existingKey]) {
                missingKeys.push(existingKey);
            }
        }
        
        if (missingKeys.length > 0) {
            throw new Error("Cannot partially update encrypted KVM. Encrypted KVM '" + kvmName + "' has existing entries that are not included in your update: [" + missingKeys.join(", ") + "]. When updating encrypted KVMs, you must provide ALL entry values, not just the ones you want to change. Existing encrypted values cannot be preserved.");
        }
    }
    
    // Step 2: Merge existing entries with new/updated entries
    var entryMap = {};
    
    // First, add all existing entries
    for (var i = 0; i < existingEntries.length; i++) {
        entryMap[existingEntries[i].name] = existingEntries[i].value;
    }
    
    // Then, update/add new entries
    for (var key in newEntries) {
        if (newEntries.hasOwnProperty(key)) {
            entryMap[key] = newEntries[key];
        }
    }
    
    // Convert map back to array
    var updatedEntryArray = [];
    for (var entryName in entryMap) {
        if (entryMap.hasOwnProperty(entryName)) {
            updatedEntryArray.push({
                name: entryName,
                value: entryMap[entryName]
            });
        }
    }
    
    // Step 3: PUT the updated KVM
    var putPayload = {
        name: kvmName,
        encrypted: currentKVM.encrypted || false,
        entry: updatedEntryArray
    };
    
    var putReq = new Request(baseUrl, "PUT", {
        "Authorization": authHeader,
        "Content-Type": "application/json"
    }, JSON.stringify(putPayload));
    
    var putExchange = httpClient.send(putReq);
    putExchange.waitForComplete();
    
    var responseStatus = putExchange.getResponse().status;
    var responseContent = "";
    
    try {
        responseContent = putExchange.getResponse().content.asString;
    } catch (contentError) {
        responseContent = "Could not read response content";
    }
    
    if (putExchange.isSuccess() && (responseStatus.code == "200" || responseStatus.code == "201")) {
        var result = {
            success: true,
            kvm_name: kvmName,
            scope: scope,
            operation: "updated",
            entries_updated: [],
            total_entries: updatedEntryArray.length
        };
        
        // List which entries were updated
        for (var key in newEntries) {
            if (newEntries.hasOwnProperty(key)) {
                result.entries_updated.push({
                    name: key,
                    status: "success"
                });
            }
        }
        
        context.setVariable("kvm.response.body", JSON.stringify(result, null, 2));
    } else {
        throw new Error("Failed to update KVM. Status: " + responseStatus.code + ", Response: " + responseContent);
    }
    
} catch (e) {
    var authHeaderValue = context.getVariable("auth.header");
    var debugInfo = {
        error: true,
        message: "Error updating KVM entries: " + e.toString(),
        stack: e.stack || "No stack trace available",
        debug: {
            kvm_name: context.getVariable("kvm.name"),
            scope: context.getVariable("kvm.scope"),
            auth_header_exists: authHeaderValue ? "yes" : "no",
            auth_header_preview: authHeaderValue ? authHeaderValue.substring(0, 20) + "..." : "none",
            org_name: context.getVariable("organization.name"),
            env_name: context.getVariable("environment.name"),
            username: context.getVariable("private.apigee_username"),
            password_exists: context.getVariable("private.apigee_password") ? "yes" : "no"
        }
    };
    context.setVariable("kvm.response.body", JSON.stringify(debugInfo, null, 2));
}