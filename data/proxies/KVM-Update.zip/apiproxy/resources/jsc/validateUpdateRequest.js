try {
    var requestBody = context.getVariable("request.content");
    
    // Parse the incoming request
    var updateData = JSON.parse(requestBody);
    
    // Validate required fields
    if (!updateData.kvm_name) {
        throw new Error("KVM name (kvm_name) is required");
    }
    
    if (!updateData.entries || Object.keys(updateData.entries).length === 0) {
        throw new Error("At least one entry to update is required");
    }
    
    // Get scope from request (default to environment)
    var scope = updateData.scope || "environment";
    
    // Store validated data
    context.setVariable("kvm.name", updateData.kvm_name);
    context.setVariable("kvm.scope", scope);
    context.setVariable("kvm.entries", JSON.stringify(updateData.entries));
    
} catch (e) {
    // Set error in response
    context.setVariable("kvm.response.body", JSON.stringify({
        error: true,
        message: "Invalid request: " + e.toString()
    }));
    
    throw e;
}