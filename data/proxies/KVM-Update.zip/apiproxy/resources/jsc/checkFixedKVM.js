 // Check if KVM name is prefixed with "fixed-" and throw error if so
try {
    var kvmName = context.getVariable("kvm.name");
    
    if (!kvmName) {
        throw new Error("KVM name not found in context");
    }
    
    // Check if KVM name starts with "updateable-"
    if (kvmName.indexOf("updateable-") !== 0) {
        // Set error response
        context.setVariable("kvm.response.body", JSON.stringify({
            error: true,
            kvm_name: kvmName,
            message: "Cannot update KVM '" + kvmName + "'. Only KVMs with names starting with 'updateable-' can be modified via this API.",
            reason: "This KVM is not marked as updateable"
        }, null, 2));
        
        throw new Error("Cannot update KVM without 'updateable-' prefix: " + kvmName);
    }
    
    // If we get here, the KVM name is valid and starts with "updateable-"
    
} catch (e) {
    // If we haven't already set an error response, set one now
    if (!context.getVariable("kvm.response.body")) {
        context.setVariable("kvm.response.body", JSON.stringify({
            error: true,
            message: "Error checking KVM name: " + e.toString()
        }, null, 2));
    }
    
    throw e;
}