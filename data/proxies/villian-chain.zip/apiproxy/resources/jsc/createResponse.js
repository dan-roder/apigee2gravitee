function safeParse(jsonStr) {
  if (!jsonStr || jsonStr === "") return null;
  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    return null;
  }
}


var r1 = safeParse(context.getVariable('backend1Response.content'));
var r2 = safeParse(context.getVariable('backend2Response.content'));
var r3 = safeParse(context.getVariable('backend3Response.content'));

var villianList = [];
if(r1 !== null){
    villianList.push(r1);
}

if(r2 !== null){
    villianList.push(r2);
}

if(r3 !== null){
    villianList.push(r3);
}

var response = villianList;

context.setVariable('response.content', JSON.stringify(villianList, null, 2));
context.setVariable('response.header.Content-Type', 'application/json');