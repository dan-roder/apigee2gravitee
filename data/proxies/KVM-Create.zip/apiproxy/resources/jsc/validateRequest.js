try {
    var requestBody = context.getVariable("request.content");
    var orgName = context.getVariable("organization.name");
    var envName = context.getVariable("environment.name");
    
    // Parse the incoming request
    var kvmData = JSON.parse(requestBody);
    
    // Validate required fields
    if (!kvmData.name) {
        throw new Error("KVM name is required");
    }
    
    // Get scope from request (default to environment)
    var scope = kvmData.scope || "environment";
    
    // Build the Management API URL based on scope
    var apiUrl;
    if (scope === "environment") {
        apiUrl = "127.0.0.1:8080/v1/organizations/" + orgName + "/environments/" + envName + "/keyvaluemaps";
    } else if (scope === "organization") {
        apiUrl = "127.0.0.1:8080/v1/organizations/" + orgName + "/keyvaluemaps";
    } else {
        throw new Error("Invalid scope. Must be 'organization' or 'environment'");
    }
    
    context.setVariable("kvm.api.url", apiUrl);
    context.setVariable("kvm.scope", scope);
    
    // Build the KVM creation payload with entries inline
    var kvmPayload = {
        name: kvmData.name,
        encrypted: kvmData.encrypted || false
    };
    
    // Add entries to the payload if provided
    if (kvmData.entries) {
        var entryArray = [];
        var entryCount = 0;
        
        for (var key in kvmData.entries) {
            if (kvmData.entries.hasOwnProperty(key)) {
                entryArray.push({
                    name: key,
                    value: kvmData.entries[key]
                });
                entryCount++;
            }
        }
        
        if (entryCount > 0) {
            kvmPayload.entry = entryArray;
            context.setVariable("kvm.has.entries", "true");
            context.setVariable("kvm.entry.count", entryCount.toString());
        } else {
            context.setVariable("kvm.has.entries", "false");
        }
    } else {
        context.setVariable("kvm.has.entries", "false");
    }
    
    context.setVariable("kvm.request.body", JSON.stringify(kvmPayload));
    
} catch (e) {
    // Set error in response
    context.setVariable("kvm.response.body", JSON.stringify({
        error: true,
        message: "Invalid request: " + e.toString()
    }));
    
    throw e;
}