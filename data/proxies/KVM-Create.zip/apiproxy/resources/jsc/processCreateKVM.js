// apiproxy/resources/jsc/processCreateKVM.js
// This script processes the KVM creation response

try {
    var createResponseContent = context.getVariable("kvm.create.response.content");
    var createStatus = context.getVariable("kvm.create.response.status.code");
    
    // Check if we got a response
    if (!createResponseContent) {
        throw new Error("No response from KVM creation");
    }
    
    var createResponse = JSON.parse(createResponseContent);
    
    // Check if KVM was created successfully
    if (createStatus != "201" && createStatus != "200") {
        throw new Error("Failed to create KVM. Status: " + createStatus + ", Response: " + createResponseContent);
    }
    
    var kvmName = createResponse.name;
    var hasEntries = context.getVariable("kvm.has.entries");
    var entryCount = context.getVariable("kvm.entry.count");
    var scope = context.getVariable("kvm.scope") || "environment";
    
    // Count actual entries returned
    var actualEntryCount = 0;
    if (createResponse.entry && createResponse.entry.length) {
        actualEntryCount = createResponse.entry.length;
    }
    
    var result = {
        success: true,
        kvm_created: kvmName,
        scope: scope,
        encrypted: createResponse.encrypted || false,
        entries_requested: entryCount || "0",
        entries_created: actualEntryCount.toString(),
        http_status: createStatus
    };
    
    // Include entry details if present
    if (createResponse.entry && createResponse.entry.length > 0) {
        result.entries = [];
        for (var i = 0; i < createResponse.entry.length; i++) {
            result.entries.push({
                name: createResponse.entry[i].name,
                value: createResponse.entry[i].value || "(encrypted/hidden)"
            });
        }
    }
    
    context.setVariable("kvm.response.body", JSON.stringify(result, null, 2));
    
} catch (e) {
    context.setVariable("kvm.response.body", JSON.stringify({
        error: true,
        message: "Error processing KVM creation: " + e.toString(),
        stack: e.stack || "No stack trace available",
        raw_response: context.getVariable("kvm.create.response.content")
    }, null, 2));
}