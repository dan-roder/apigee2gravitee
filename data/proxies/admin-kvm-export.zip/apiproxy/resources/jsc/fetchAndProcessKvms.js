var kvms = JSON.parse(context.getVariable("kvmListResponse.content"));
var output = {};

for (var i = 0; i < kvms.length; i++) {
  var kvm = kvms[i];

  var resp = httpClient.send({
    method: "GET",
    url:
      "https://apigee.grover.advana.aws.540.dev/v1/organizations/" +
      context.getVariable("org") +
      "/environments/" +
      context.getVariable("env") +
      "/keyvaluemaps/" +
      kvm +
      "/entries",
    headers: {
      Authorization: context.getVariable("request.header.Authorization"),
      Accept: "application/json"
    }
  });

  var resp = httpClient.send(req);
  var entries = JSON.parse(resp.response.content).keyValueEntries || [];

  result[kvm] = {};
  for (var j = 0; j < entries.length; j++) {
    result[kvm][entries[j].name] = entries[j].value;
  }
}

context.setVariable("response.content", JSON.stringify(result, null, 2));
context.setVariable("response.header.Content-Type", "application/json");
