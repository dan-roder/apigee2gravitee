     // processEncryptedValue.js
    var decryptedValue = context.getVariable("private.secret-password-1");
    var myVariable = context.getVariable("private.secret-password-1")
    // Set a new response header with the variable's value
    context.setVariable("response.header.X-Custom-Header", myVariable);