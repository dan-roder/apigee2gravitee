    // processEncryptedValue.js
    var decryptedValue = context.getVariable("private.super-secret-email");
    var myVariable = context.getVariable("private.super-secret-email")
    // Set a new response header with the variable's value
    context.setVariable("response.header.X-Custom-Header", myVariable);
    // Now you can use 'decryptedValue' in your JavaScript logic
    // For example, you could use it to construct an authorization header
    // or perform other operations.
   // console.log("Decrypted value: " + decryptedValue); // This would not work as 'print' or 'console.log' won't show private variables 