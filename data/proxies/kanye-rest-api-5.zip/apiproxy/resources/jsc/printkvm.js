// Define a variable
var myVariable = "super-secret-email";
// You can also print flow variables directly
print(context.getVariable("super-secret-email"));