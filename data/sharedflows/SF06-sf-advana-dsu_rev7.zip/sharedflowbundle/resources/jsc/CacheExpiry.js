var expiryTime= context.getVariable("expiryTime");
expiryTime = expiryTime - 60;
expiryTime = (parseInt(expiryTime, 10) +1).toFixed(0);
context.setVariable("expiryTime", expiryTime);