//This transform is specifically made to convert column names
// in an Advana delta connector query
var findValidId = /^[\w-_:,\.]+$/
var findEndSpacing = /\s+$/
var firstColumnName
var validOperators = {
  lt: true,
  lte: true,
  gt: true,
  gte: true,
  eq: true,
  neq: true,
  like: true,
  in: true
}
var validParameters = { fields: true, filters: true, offset: true, limit: true }

//the "fields" parameter in the query is used to
//choose which fields will appear in the result
function transformFields (query, columnMap, validFieldNames) {
  var result = { error: null }
  //case for multiple fields parameters i.e. fields=x&fields=y
  if (query && query.fields && Array.isArray(query.fields)) {
    for (var x = 0; x < query.fields.length; x++) {
      var fieldName = query.fields[x]
      if (!validFieldNames[fieldName]) {
        result = {
          error:
            "The value provided for the 'fields' parameter contains an unknown field name: '" +
            fieldName +
            ".'"
        }
        break
      }
      //if we have a mapping for this field name, like {"bldgState": "Bldg State"}
      if (columnMap.hasOwnProperty(fieldName)) {
        //query.fields[x] is now changed from "bldgState" to "Bldg State"
        query.fields[x] = columnMap[fieldName]
      }
    }
  }
  //case for a single fields parameter
  else if (query && query.fields && !Array.isArray(query.fields)) {
    var fieldName = query.fields
    if (!validFieldNames[fieldName]) {
      result = {
        error:
          "The value provided for the 'fields' parameter contains an unknown field name: '" +
          fieldName +
          ".'"
      }
    } else if (columnMap.hasOwnProperty(fieldName)) {
      //query.fields[x] is now changed from "bldgState" to "Bldg State"
      query.fields = columnMap[fieldName]
    }
  }
  return result
}

/*
 Handle the case where a rest query against the table's id
 is being performed (where the path to the proxy looks like "/{base path}/{id}" )
*/
function handlePathFilter (query, columnMap, uri) {
  try {
    //get the proxy basepath like /aerialShipments/events
    var proxyBasePath = context.getVariable('proxy.basepath')

    //get the actual path being called like /aerialShipments/events/ID123
    var path = uri['_parts'].path

    //get the name of the column in the table that functions as the unique ID
    var idColumnName = context.getVariable('idColumnName')

    // In the case that someone gets mixed up and gives the camelCase
    // version of the column name, map it to the delta table column name
    if (columnMap[idColumnName]) {
      idColumnName = columnMap[idColumnName]
    }
    //if idColumnName is not set, then use the first column name in context.getVariable('columnMapping')
    else if (firstColumnName) {
      idColumnName = firstColumnName
    }

    /* check if the idColumnName is set in the policy xml and the API path being called is like /{base path}/{id}
    Notes:
    - only accepts paths that are less that 1000 characters (for purposes of data untainting)
    */
    if (
      idColumnName &&
      proxyBasePath &&
      path.length < 1000 &&
      path.length > proxyBasePath.length + 1
    ) {
      //get the {id} at the end of the path
      var id = path.substring(proxyBasePath.length + 1)

      //remove whitespace from the end of the id, if any
      id = id.replace(findEndSpacing, '')
      if (id) {
        if (id.length < 42 && findValidId.test(id)) {
          var idQuery = idColumnName + '~eq~' + id
          //if no query.filters exists, add it
          if (!query.filters) {
            query.filters = idQuery
          }
          //if query.filters is an array, push this query on the end
          else if (Array.isArray(query.filters)) {
            query.filters.push(idQuery)
          }
          //if only one query exists (query.filters is not an array), add it and idQuery into an array of filters
          else {
            query.filters = [query.filters, idQuery]
          }
        }
      }
    }
  } catch (e) {
    print('--- Error when checking path for /[basePath]/{id} style rest query:', e)
  }
}

function transformFilters (query, columnMap, uri, validFieldNames) {
  // handle the case where a rest query against the table's id
  // is being performed (where the path to the proxy looks like "/{base path}/{id}" )
  handlePathFilter(query, columnMap, uri)

  if (query && query.filters) {
    //if there is only one filter, put it into an array
    //so that the next set of code that work with it
    if (!Array.isArray(query.filters)) {
      query.filters = [query.filters]
    }
    //iterate through the filters and convert field names
    //within them
    for (var x = 0; x < query.filters.length; x++) {
      //split the filter at the OR operator "||", in case one or more exist
      var filters = query.filters[x].split('||')
      //iterate through the filter(s)
      for (var f = 0; f < filters.length; f++) {
        //split the filter at the tilde - example: "bldgState~eq~CA"
        var filterParts = filters[f].split('~')

        //filterParts looks like ["bldgState", "eq", "CA"]

        if (filterParts && filterParts.length === 3) {
          var filterField = filterParts[0]
          var filterOperator = filterParts[1]
          if (validOperators.hasOwnProperty(filterOperator)) {
            if (validFieldNames.hasOwnProperty(filterField)) {
              //check the column name in the filter to see if a mapping exists for it
              if (columnMap.hasOwnProperty(filterField)) {
                //convert the column name from something like "bldgState" to "Bldg State"
                filterParts[0] = columnMap[filterField]
                filters[f] = filterParts.join('~')
                //filters[f] now looks like "Bldg State~eq~CA"
              }
            } else {
              return {
                error:
                  "An unrecognized field name, '" +
                  filterField +
                  "', was detected in the filter query: '" +
                  filters[f] +
                  ".' Please review the query and ensure the field name is correct and supported."
              }
            }
          } else {
            return {
              error:
                "An unrecognized query operator: '" +
                filterOperator +
                "', was detected in the filter query: '" +
                filters[f] +
                "' Please review the query and ensure the query operator is one of the following: lt, lte, gt, gte, eq, neq, like, or in."
            }
          }
        } else {
          return {
            error:
              "The structure of the filter query, '" +
              filters[f] +
              "', is not recognized. Please ensure your filter query follows the correct structure: 'filters=[field name]~[operator]~value' ."
          }
        }
      }
      query.filters[x] = filters.join('||')
    }
  }
  return { error: null }
}

//this iterates through the query object and sets message.queryparam.[param].[param index]
//setting multiple "param index" for the same parameter supports the ability
//to do queries like ?filter=a~eq~abc&filter=b~eq~def
function updateQuery (query) {
  if (query) {
    //iterate through the keys in the query map
    for (var param in query) {
      //get the value of the key
      var paramValue = query[param]
      //if the value is an array, iterate through it
      if (Array.isArray(paramValue)) {
        for (var x = 0; x < paramValue.length; x++) {
          //overwrite the original query parameter with the (potentially) modified one
          context.setVariable(
            'message.queryparam.' + param + '.' + (x + 1),
            paramValue[x]
          )
        }
      }
      //else the value is a string
      else {
        //overwrite the original query parameter with the (potentially) modified one
        context.setVariable('message.queryparam.' + param + '.1', paramValue)
      }
    }
  }
}

//create a map like {apiQueryField: deltaConnectorfield} example: {"bldgState": "Bldg State"}
function createColumnMaps (columnMapString) {
  var validFieldNames = {}
  var columnMap = {}
  if (columnMapString) {
    // columnMapString is comma delimited in format: deltaColumnName,camelCaseName,deltaColumnName,camelCaseName ...
    var rawMapping = columnMapString.split(',')
    for (var x = 0; x < rawMapping.length; x = x + 2) {
      var deltaColumnName = rawMapping[x]
      var camelCaseName = rawMapping[x + 1]
      if (x === 0) {
        firstColumnName = deltaColumnName
      }
      columnMap[camelCaseName] = deltaColumnName
      validFieldNames[deltaColumnName] = true
      validFieldNames[camelCaseName] = true
    }
  }
  return { columnMap: columnMap, validFieldNames: validFieldNames }
}

function checkForUnknownParameters (queryObj) {
  var invalidParameters = []
  for (var parameter in queryObj) {
    if (!validParameters[parameter]) {
      invalidParameters.push(parameter)
    }
  }

  if (invalidParameters.length > 0) {
    return {
      error:
        'The query includes invalid parameters: ' +
        invalidParameters.join(', ') +
        '. Please ensure that your query only contains the following valid parameters: filter, fields, limit, and offset.'
    }
  }
  return { error: null }
}

//Apigee does not expose duplicate query string names in an iterable way within the context variables
//so, it's required to get the raw querystring and parse it
var uri = URI(context.getVariable('request.uri'))
print('\n-- original uri:', JSON.stringify(uri, null, 2))
var queryObj = uri.search(true)

//create a map of "query column name"->"delta table column name"
var columnMaps = createColumnMaps(context.getVariable('columnMapping'))
var columnMap = columnMaps.columnMap
var validFieldNames = columnMaps.validFieldNames

var transformFieldsResult = transformFields(
  queryObj,
  columnMap,
  validFieldNames
)
var transformFiltersResult = transformFilters(
  queryObj,
  columnMap,
  uri,
  validFieldNames
)
var checkForUnknownParametersResult = checkForUnknownParameters(queryObj)

var errors = []
var errorCount = 1

if (checkForUnknownParametersResult.error) {
  errors.push(checkForUnknownParametersResult.error)
}
if (transformFieldsResult.error) {
  errors.push(transformFieldsResult.error)
}
if (transformFiltersResult.error) {
  errors.push(transformFiltersResult.error)
}
if (errors.length > 1) {
  for (var x = 0; x < errors.length; x++) {
    errors[x] = x + 1 + '. ' + errors[x]
  }
}

if (errors.length > 0) {
  context.setVariable('flow.errorStatusCode', 400)
  context.setVariable('flow.errorUserMessage', JSON.stringify({ message: errors.join(' ') }, null, 2))
  context.setVariable('isMalformedRequest', 'yes')
} 
else {
  updateQuery(queryObj)

  print('\n-- query object after transform:', JSON.stringify(queryObj, null, 2))

  print('\n-- targetUrl:', context.getVariable('target.url'))
}
