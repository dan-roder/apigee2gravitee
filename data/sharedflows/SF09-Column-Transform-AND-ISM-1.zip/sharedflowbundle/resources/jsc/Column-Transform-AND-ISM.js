 
function zeroPad (num) {
  if (num < 10) {return '0' + num}
  return num
}

var columnMap = {}
var hasCachedColumnNames = false
var existingColumnNames = []
var newColumnNames = []
var existingColumnNamesLength
//renames the columns in a single row of data
//Has a caching capability to speed performance
function renameColumns (row) {
  //if a cache exists, use it to do the mapping
  if (hasCachedColumnNames) {
    //print("There are cached columns!")
    for (var x=0;x<existingColumnNamesLength;x++) {
      var existingColumnName = existingColumnNames[x]
      if (newColumnNames[x]==existingColumnName){
          //print("Same as existing ", JSON.stringify(row))
          // do nothing
          continue;
        } 
        else {
          row[newColumnNames[x]] = row[existingColumnName]
          delete row[existingColumnName]
    }
  }}
  //first time through, create a cache (uses arrays, rather than maps) to use in the subsequent rows
  else {
    for (existingColumnName in row) {
      if (columnMap[existingColumnName]) {
        var newColumnName = columnMap[existingColumnName]
        existingColumnNames.push(existingColumnName)
        newColumnNames.push(newColumnName)
        if (newColumnName==existingColumnName){
          //print(JSON.stringify(row))
          // do nothing
          continue;
        }
        else {
        row[newColumnName] = row[existingColumnName]
        delete row[existingColumnName]
      }
    }
    existingColumnNamesLength = existingColumnNames.length
    hasCachedColumnNames = true
  }
}}

function getCurrentDate () {
  var createDate = new Date()
  return createDate.getUTCFullYear() + '-' + zeroPad(createDate.getUTCMonth() + 1) + '-' + zeroPad(createDate.getUTCDate())
}

function getISM (ismDate, highestDataClassification) {
  //if no ismDate exists, set it to the present
  if (!ismDate) {ismDate = getCurrentDate()}
  return {
    ism_version: '1.0',
    ism_resourceElement: true,
    ism_compliesWith: 'USDOD',
    ism_createDate: ismDate,
    ism_classification: highestDataClassification,
    ism_ownerProducer: 'USA'
  }
}

function handleMarkingAndColumnMapping (columnMapping, response) {
  var start = Date.now()
  if (response) {
    var highestDataClassification = context.getVariable('highestDataClassification')
    if (highestDataClassification) {
      print('highestDataClassification:', highestDataClassification)
      var ismDate = context.getVariable('ismCreateDate')
      if (!ismDate) {
        var createDate = new Date()
        ismDate = createDate.getUTCFullYear() + '-' + zeroPad(createDate.getUTCMonth() + 1) + '-' + zeroPad(createDate.getUTCDate())
      }
      response.ism = getISM(ismDate, highestDataClassification)
    } 
    
    columnMap = {}
    var rawMapping = columnMapping.split(',')
    for (var x = 0; x < rawMapping.length; x = x + 2) {
      columnMap[rawMapping[x]] = rawMapping[x + 1]
    }

   try {
      var rows = response.content.data;
      //print('rows:', JSON.stringify(rows))
      for (var r = 0; r < rows.length; r++) {
        renameColumns(rows[r])
      }
      //update the proxy response
      //response.content = content;
    } catch (e) {
      response.SharedFlowTransformError = 'Error while transforming rows:' + e
    }

    print('duration:', Date.now() - start, 'ms')
  } else {
    print('the response object was null or undefined')
  }
}

var columnMapping = context.getVariable('columnMapping')
var response
if (context.proxyResponse &&
  context.proxyResponse.content &&
  context.proxyResponse.content.asJSON &&
  context.proxyResponse.content.asJSON) {
  response = context.proxyResponse.content.asJSON
}
if (columnMapping) {   
  handleMarkingAndColumnMapping(columnMapping, response)
}