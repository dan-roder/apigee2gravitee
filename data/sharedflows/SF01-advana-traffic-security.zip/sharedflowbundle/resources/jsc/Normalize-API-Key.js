 var apiKey = context.getVariable("request.header.apikey")
 
 if (!apiKey) {
     var authHeader = context.getVariable("request.header.Authorization")
     if (authHeader && authHeader.toLowerCase().indexOf("bearer ") === 0) {
         apiKey = authHeader.substring(7).trim();
     }
 }
 
 context.removeVariable("request.header.Authorization")
 context.setVariable("private.normalized_api_key", apiKey || "")